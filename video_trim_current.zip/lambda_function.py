import json
import os
import subprocess
import urllib.request
import uuid
import boto3

s3 = boto3.client("s3")

BUCKET = os.environ.get("BUCKET", "airdate.tv")
OUTPUT_PREFIX = os.environ.get("OUTPUT_PREFIX", "social/trailers-trimmed/")
CDN_BASE = os.environ.get("CDN_BASE", "https://airdate.tv")
MAX_DURATION_SECONDS = int(os.environ.get("MAX_DURATION_SECONDS", "110"))  # safely under Twitter's 2-min cap

FFMPEG_BIN = "/opt/bin/ffmpeg"  # path provided by the ffmpeg Lambda layer


def lambda_handler(event, context):
    try:
        body = event.get("body")
        if isinstance(body, str):
            body = json.loads(body)
        elif body is None:
            body = event  # allow direct invoke without API Gateway wrapping

        source_url = body.get("url")
        if not source_url:
            return _response(400, {"error": "Missing 'url' in request body"})

        job_id = str(uuid.uuid4())
        input_path = f"/tmp/{job_id}_in.mp4"
        output_path = f"/tmp/{job_id}_out.mp4"

        # Download source video
        urllib.request.urlretrieve(source_url, input_path)

        # Trim to MAX_DURATION_SECONDS using stream copy (fast, no re-encode/quality loss)
        cmd = [
            FFMPEG_BIN,
            "-y",
            "-i", input_path,
            "-t", str(MAX_DURATION_SECONDS),
            "-c", "copy",
            "-movflags", "+faststart",
            output_path,
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode != 0 or not os.path.exists(output_path):
            # Fallback: some sources need re-encoding if stream copy fails on the cut point
            cmd_reencode = [
                FFMPEG_BIN,
                "-y",
                "-i", input_path,
                "-t", str(MAX_DURATION_SECONDS),
                "-c:v", "libx264",
                "-preset", "veryfast",
                "-c:a", "aac",
                "-movflags", "+faststart",
                output_path,
            ]
            result2 = subprocess.run(cmd_reencode, capture_output=True, text=True)
            if result2.returncode != 0 or not os.path.exists(output_path):
                return _response(500, {
                    "error": "ffmpeg failed",
                    "stderr_copy": result.stderr[-2000:],
                    "stderr_reencode": result2.stderr[-2000:],
                })

        # Upload trimmed video to S3
        key = f"{OUTPUT_PREFIX}{job_id}.mp4"
        s3.upload_file(
            output_path,
            BUCKET,
            key,
            ExtraArgs={"ContentType": "video/mp4"},
        )

        trimmed_url = f"{CDN_BASE}/{key}"

        # Cleanup /tmp
        for p in (input_path, output_path):
            if os.path.exists(p):
                os.remove(p)

        return _response(200, {"trimmed_url": trimmed_url})

    except Exception as e:
        return _response(500, {"error": str(e)})


def _response(status_code, body_dict):
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body_dict),
    }
